// #include "../include/schedulersim/pcb.h"

#include "../include/schedulersim/schedulers/schedulerRoundRobin.h"

#include <algorithm>
#include <thread>
#include <vector>

#include "../include/schedulersim/time_frame.h"
#include "../include/schedulersim/utils.h"

int SchedulerRoundRobin::validator(TimeFrame *tf) {
    Quantum q = tf->back();
    std::vector<PCB> pcb_vec = q.get_vec();
    std::vector<PCB> sortedStartVec =
        sortedVec(pcb_vec, [](PCB &a, PCB &b) { return a.start < b.start; });
    if (q.getPeriod() == -1) {
        // std::vector<PCB> sortedStartVec = sortedVec(pcb_vec, [](PCB &a, PCB
        // &b){return a.start < b.start;});
        for (std::size_t i = 0; i < sortedStartVec.size(); i++) {
            pid_queue->push(i);
            pid_queue->push(i);
        }
    }

    std::size_t size_queue = pid_queue->size();

    std::vector<PCB> canStartVec = getReadyPCBVec(pcb_vec);
    int pid = -1;
    if (canStartVec.size() > 0) {
        for (std::size_t i = 0; i < size_queue; i++) {
            pid = pid_queue->front();
            pid_queue->pop();
            if (!q.get(pid).hasFinished()) {
                pid_queue->push(pid);
            }
            if (q.get(pid).canStart(q.getPeriod() + 1)) {
                break;
            }
        }
    }

    return pid;
}

SchedulerRoundRobin::~SchedulerRoundRobin() {
    delete pid_queue;
}