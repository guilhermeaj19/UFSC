// #include "../include/schedulersim/pcb.h"
#include "../include/schedulersim/time_frame.h"
#include "../include/schedulersim/utils.h"
#include "../include/schedulersim/schedulers/schedulerSJF.h"
#include <algorithm>
#include <iostream>
#include <vector>

int SchedulerSJF::validator(TimeFrame *tf) {
    Quantum q = tf->back();

    //Verifica se processo ainda não terminou de executar
    for (std::size_t i = 0; i < q.get_vec().size(); i++) {
        PCB currentPCB = q.get_vec().at(i);
        if (!currentPCB.hasFinished() && currentPCB.state == PCB::states::RUNNING) {
            return currentPCB.pid;
        }
    }
    std::vector<PCB> pcb_vec = q.get_vec();
    std::vector<PCB> canStartVec = getReadyPCBVec(pcb_vec);
    canStartVec = sortedVec(canStartVec, [](PCB &a, PCB &b){return a.duration < b.duration;});
    if (canStartVec.size() == 0) return -1;
    int pid = canStartVec.at(0).pid;
    return pid;
}