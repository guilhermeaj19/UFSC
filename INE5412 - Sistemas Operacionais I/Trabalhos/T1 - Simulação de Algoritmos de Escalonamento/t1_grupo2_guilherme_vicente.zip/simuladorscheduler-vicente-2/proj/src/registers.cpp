#include "../include/schedulersim/registers.h"
#include <stdlib.h>
#include <random>

Registers randomRegisters()
{
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<int64_t> dis;
    std::uniform_int_distribution<uint64_t> dis_u;
    Registers newRegister;
    for (int i = 0; i < 6; i++)
    {
        newRegister.gp[i] = dis(gen);
    }
    newRegister.sp = dis_u(gen);
    newRegister.pc = dis_u(gen);
    newRegister.st = dis(gen);
    return newRegister;
}