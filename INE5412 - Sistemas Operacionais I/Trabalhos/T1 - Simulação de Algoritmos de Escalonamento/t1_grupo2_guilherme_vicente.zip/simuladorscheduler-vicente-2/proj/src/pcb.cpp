#include "../include/schedulersim/pcb.h"

#include <algorithm>
#include <iostream>
#include <optional>
PCB::PCB() {
    // Faz referência a um período de quantum, -1 para inexistente
    currentQuantum = -1;
    state = NEW;
    registers = randomRegisters();
    contextChanges = 0;
}

PCB::PCB(int pid_, int start_, int duration_, int priority_,
         int contextChanges_, int waitingTime_, int executionElapsed_,
         int currentQuantum_, Registers registers_, states state_) {
    pid = pid_;
    start = start_;
    duration = duration_;
    priority = priority_;
    contextChanges = contextChanges_;
    waitingTime = waitingTime_;
    executionElapsed = executionElapsed_;
    currentQuantum = currentQuantum_;
    registers = registers_;
    state = state_;
}

int PCB::getWaitingTime() { return waitingTime; }

int PCB::getRemainingExecTime() { return duration - executionElapsed; }

int PCB::getCurrentQuantum() { return currentQuantum; }

int PCB::getExecutionElapsed() { return executionElapsed; }

int PCB::getTurnAround() {return executionElapsed + waitingTime;}

bool PCB::hasFinished() { return getRemainingExecTime() == 0; }

bool PCB::canStart(int quantum) {
    return (quantum >= start) && (!hasFinished());
}

int PCB::getContextChanges() { return contextChanges; }

void PCB::setNonRunningPCB(PCB* p) {
    if (p->canStart(p->currentQuantum)) {
        p->waitingTime++;
        p->state = READY;
    } else if (p->hasFinished()) {
        p->state = FINISHED;
    }
}

void PCB::setRunningPCB(PCB* p) {
    if (p->canStart(p->currentQuantum)) {
        if (p->state == NEW || p->state == READY) {
        p->contextChanges++;
        }
        p->executionElapsed++;
        p->state = RUNNING;
    } else {
        throw std::runtime_error("Valor inválido");
    }
}

// Retorna a step da PCB baseada na condição de execução
PCB PCB::step(bool running) {
    PCB p = *this;
    p.currentQuantum++;

    if (running) {
        setRunningPCB(&p);
    } else {
        setNonRunningPCB(&p);
    }

    return p;
}