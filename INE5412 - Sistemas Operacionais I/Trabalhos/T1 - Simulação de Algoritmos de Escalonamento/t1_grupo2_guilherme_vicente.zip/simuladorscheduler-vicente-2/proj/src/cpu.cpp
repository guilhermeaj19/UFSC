#include "../include/schedulersim/cpu.h"

void CPU::reset()
{
    registers = defaultRegisters;
}

CPU::CPU()
{
    reset();
}

CPU::CPU(std::string name_, Registers &registers_)
{
    name = name_;
    registers = registers_;
}

CPU::~CPU() {}