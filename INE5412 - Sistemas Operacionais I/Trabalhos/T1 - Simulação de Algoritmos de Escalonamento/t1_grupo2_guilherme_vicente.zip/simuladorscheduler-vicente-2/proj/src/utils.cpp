#include "../include/schedulersim/utils.h"
#include "../include/input/read_file.h"
#include <vector>
#include <algorithm>

std::vector<PCB> createPCBVec(std::string s) {
    File f;
    f.read_file(s);
    vector<ProcessParams> process = f.get_processes();
    vector<PCB> pcb_vec;
    for (std::size_t i = 0; i < process.size(); i++) {
        PCB newPCB;
        newPCB = PCB(i, process.at(i).get_creation_time(),
        process.at(i).get_duration(), process.at(i).get_priority());
        // std::cout << newPCB.getWaitingTime();
        pcb_vec.push_back(newPCB);
    }
    return pcb_vec;
}

std::vector<PCB> getReadyPCBVec(std::vector<PCB> &pcb_vec) {
    return filterVec(pcb_vec, [](PCB &a) {
        return a.canStart(a.getCurrentQuantum() > 0 ? a.getCurrentQuantum() + 1
                                                    : 0);
    });
};