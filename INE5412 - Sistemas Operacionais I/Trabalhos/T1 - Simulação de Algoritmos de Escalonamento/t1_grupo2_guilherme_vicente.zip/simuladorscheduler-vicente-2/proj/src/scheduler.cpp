#include "../include/schedulersim/schedulers/scheduler.h"

int Scheduler::validator(TimeFrame *tf) { tf= tf; return 0; }

TimeFrame Scheduler::execute(std::vector<PCB> &setup_vec){
    TimeFrame tf(setup_vec);
    while (!tf.hasFinished()) {
        int pid = validator(&tf);
        tf.next(pid);
    }
    return tf;
}
