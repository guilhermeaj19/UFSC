#include "../include/schedulersim/simulator.h"

#include <iostream>
#include <memory>
#include <string>
#include "../include/schedulersim/schedulers/scheduler.h"
#include "../include/schedulersim/schedulers/schedulerFCFS.h"
#include "../include/schedulersim/schedulers/schedulerPriorityNoPreemption.h"
#include "../include/schedulersim/schedulers/schedulerPriorityWithPreemption.h"
#include "../include/schedulersim/schedulers/schedulerRoundRobin.h"
#include "../include/schedulersim/schedulers/schedulerSJF.h"


Simulator::Simulator(/* args */) {
    scheduler_vec.push_back(std::unique_ptr<Scheduler>(new SchedulerFCFS()));
    name_vec.push_back("FCFS");

    scheduler_vec.push_back(std::unique_ptr<Scheduler>(new SchedulerSJF()));
    name_vec.push_back("SJF");

    scheduler_vec.push_back(std::unique_ptr<Scheduler>(new SchedulerPriorityWithPreemption()));
    name_vec.push_back("Priority With Preemption");

    scheduler_vec.push_back(std::unique_ptr<Scheduler>(new SchedulerPriorityNoPreemption()));
    name_vec.push_back("Priority No Preemption");

    // scheduler_vec.push_back(std::unique_ptr<Scheduler>(new SchedulerRoundRobin()));
    // name_vec.push_back("Round Robin");
}
Simulator::~Simulator() {}

void Simulator::execute(std::vector<PCB> pcb_vec) {
    for (std::size_t i = 0; i < scheduler_vec.size(); i++) {
        std::unique_ptr<Scheduler> &scheduler = scheduler_vec.at(i);
    std::cout << std::endl << "Executando com Scheduler "
              << name_vec.at(i) << std::endl;
    TimeFrame t = scheduler->execute(pcb_vec);
    t.printResults();
    }

    //Round Robin é exceção:
    SchedulerRoundRobin rr;
    std::cout << std::endl << "Executando com RoundRobin" << std::endl;
    TimeFrame t = rr.execute(pcb_vec);
    t.printResults();

}