#include "../include/schedulersim/quantum.h"

#include <numeric>

void Quantum::resetContext() {
    runningPCB.reset();
    cpu.reset();
}

void Quantum::setContext() {
    resetContext();
    for (std::size_t i = 0; i < pcb_vec.size(); i++) {
        PCB p = pcb_vec[i];
        // if (p.state == PCB::states::RUNNING) {
        //     runningPCB = p;
        //     cpu.registers = p.registers;
        //     break;
        // }
        if (!p.hasFinished() && p.state == PCB::states::RUNNING) {
            runningPCB = p;
            cpu.registers = p.registers;
            break;
        }
    }
}

Quantum::Quantum() { setContext(); }

Quantum::Quantum(int period_) {
    period = period_;
    setContext();
}

Quantum::Quantum(int period_, std::vector<PCB> &pcb_vec_) {
    pcb_vec = pcb_vec_;
    period = period_;
    setContext();
}

void Quantum::push_back(PCB &pcb_) {
    pcb_vec.push_back(pcb_);
    setContext();
}

void Quantum::insert(PCB &pcb_, int n) {
    pcb_vec.insert(pcb_vec.begin() + n, pcb_);
    setContext();
}

void Quantum::erase(int n) {
    pcb_vec.erase(pcb_vec.begin() + n);
    setContext();
}

void Quantum::pop_back() {
    pcb_vec.pop_back();
    setContext();
}

std::size_t Quantum::size() { return pcb_vec.size(); }

PCB Quantum::get(int n) { return pcb_vec.at(n); }

int Quantum::getContextChanges() {
    return std::accumulate(
        pcb_vec.begin(), pcb_vec.end(), 0,
        [](int acc, PCB &obj) { return acc + obj.getContextChanges(); });
}

int Quantum::getPeriod() { return period; }

float Quantum::getAverageWait() {
    float average = 0;
    if (pcb_vec.size() > 0) {
        int sum = std::accumulate(
            pcb_vec.begin(), pcb_vec.end(), 0,
            [](int acc, PCB &obj) { return acc + obj.getWaitingTime(); });
        average = float(sum) / float(pcb_vec.size());
    }
    return average;
}

float Quantum::getAverageTurnAround() {
    float average = 0;
    if (pcb_vec.size() > 0) {
        int sum = std::accumulate(
            pcb_vec.begin(), pcb_vec.end(), 0,
            [](int acc, PCB &obj) { return acc + obj.getTurnAround(); });
        average = float(sum) / float(pcb_vec.size());
    }
    return average;
}

bool Quantum::hasFinished() {
    for (std::size_t i = 0; i < pcb_vec.size(); i++) {
        if (!pcb_vec.at(i).hasFinished()) {
            return false;
        }
    }
    return true;
}

std::optional<PCB> Quantum::getRunningPcb() { return runningPCB; }

Quantum Quantum::step(int pid) {
    Quantum q = *this;
    for (std::size_t i = 0; i < q.pcb_vec.size(); i++) {
        PCB &currentPcb = q.pcb_vec.at(i);
        int currentPID = currentPcb.pid;
        bool is_running = currentPID == pid;
        currentPcb = currentPcb.step(is_running);
    }
    q.period++;
    return q;
}

std::vector<PCB> Quantum::get_vec() { return pcb_vec; }

Quantum::~Quantum() {}