// #include "../include/schedulersim/pcb.h"
#include "../include/schedulersim/time_frame.h"
#include "../include/schedulersim/utils.h"
#include "../include/schedulersim/schedulers/schedulerPriorityWithPreemption.h"
#include <algorithm>
#include <vector>

int SchedulerPriorityWithPreemption::validator(TimeFrame *tf) {
    Quantum q = tf->back();
    std::vector<PCB> pcb_vec = q.get_vec();
    std::vector<PCB> canStartVec = getReadyPCBVec(pcb_vec);
    canStartVec = sortedVec(canStartVec, [](PCB &a, PCB &b){return a.priority > b.priority;});
    if (canStartVec.size() == 0) return -1;
    int pid = canStartVec.at(0).pid;
    return pid;
}