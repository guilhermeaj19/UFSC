#include "../include/schedulersim/time_frame.h"

#include <iomanip>
#include <iostream>

TimeFrame::TimeFrame(std::vector<PCB> setup_vec_) {
    setup_vec = setup_vec_;
    Quantum q(-1, setup_vec);
    quantumVec.push_back(q);
}

TimeFrame::TimeFrame() {}

TimeFrame::~TimeFrame() {}

// Realiza uma step e adiciona o quantum ao vetor
Quantum TimeFrame::next(int pid) {
    Quantum q = quantumVec.back().step(pid);
    quantumVec.push_back(q);
    return q;
}

Quantum TimeFrame::get(int i) { return quantumVec.at(i+1); }

Quantum TimeFrame::back() { return quantumVec.back(); }

int TimeFrame::getContextChanges() {
    if (quantumVec.size() > 0) {
        // Retorna o número elapsedTotal do final da execução
        return quantumVec.back().getContextChanges();
    }
    return 0;
}

float TimeFrame::getAverageWait() {
    if (quantumVec.size() > 0) {
        // Retorna a média do final da execução
        return quantumVec.back().getAverageWait();
    }
    return 0;
}

int TimeFrame::turnaround() {
    // Implementar
    return 0;
}

void TimeFrame::printResults() {
    Quantum last_quantum = quantumVec.back();
    //Primeira Linha
    std::cout << std::endl << "Turnaround by respective process" << std::endl;
     for (size_t i = 0; i < last_quantum.size(); i++) {
         std::cout << std::setw(4) << std::left << "P" +
         std::to_string(last_quantum.get(i).pid + 1) + ": "; std::cout <<
         std::to_string(last_quantum.get(i).getTurnAround()) << std::endl;
     }
     std::cout << "Average turnaround time: " +
     std::to_string(last_quantum.getAverageTurnAround()) << std::endl;

    std::cout << "Average Waiting Time: " << std::to_string(getAverageWait())
    << std::endl;

    std::cout << "Total Context Changes: " <<
    std::to_string(getContextChanges()) << std::endl;

    std::cout << std::setw(7) << std::left << "tempo";

    for (size_t i = 0; i < last_quantum.size(); i++) {
        std::cout << std::setw(4) << std::left
                  << "P" + std::to_string(last_quantum.get(i).pid + 1);
    }
    std::cout << std::endl;
    // Linhas seguintes
    for (size_t i = 1; i < quantumVec.size(); i++) {
        std::cout << std::setw(7) << std::left
                  << std::to_string(i-1) + "-" + std::to_string(i);
        Quantum quantum = quantumVec.at(i);
        for (size_t j = 0; j < quantum.size(); j++) {
            PCB process = quantum.get(j);
            std::cout << std::setw(4) << std::left;
            if (process.state == 0 || process.state == 3) std::cout << "   ";
            if (process.state == 1) std::cout << "--";
            if (process.state == 2) std::cout << "##";
        }
        std::cout << std::endl;
    }
}

bool TimeFrame::hasFinished() {
    if (quantumVec.size() == 0) {
        return false;
    } else {
        return quantumVec.back().hasFinished();
    }
}