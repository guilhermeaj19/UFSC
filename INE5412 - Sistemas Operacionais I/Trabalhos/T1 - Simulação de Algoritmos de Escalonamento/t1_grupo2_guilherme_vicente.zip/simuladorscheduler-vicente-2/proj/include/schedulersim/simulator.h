#pragma once
#include <vector>
#include "schedulers/scheduler.h"
#include <memory>
#include <string>
class Simulator
{
private:
    std::vector<std::unique_ptr<Scheduler>> scheduler_vec;
    std::vector<std::string> name_vec;
public:
void execute(std::vector<PCB> pcb_vec);
    Simulator(/* args */);
    ~Simulator();
};

