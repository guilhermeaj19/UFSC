#pragma once
#include <algorithm>
#include <string>
#include <vector>

#include "pcb.h"

std::vector<PCB> createPCBVec(std::string s);

template <typename Func>
std::vector<PCB> filterVec(std::vector<PCB> v, Func &&lambda) {
    std::vector<PCB> newFilteredVec;
    std::copy_if(v.begin(), v.end(), std::back_inserter(newFilteredVec),
                 lambda);
    return newFilteredVec;
}
template <typename Func>
std::vector<PCB> sortedVec(std::vector<PCB> v, Func &&lambda) {
    std::vector<PCB> newSortedVec = v;
    std::sort(newSortedVec.begin(), newSortedVec.end(), lambda);
    return newSortedVec;
}

std::vector<PCB> getReadyPCBVec(std::vector<PCB> &pcb_vec);