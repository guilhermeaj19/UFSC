#pragma once
#include "scheduler.h"

class SchedulerPriorityNoPreemption: public Scheduler {
    protected:
        int validator(TimeFrame *tf) override;
};