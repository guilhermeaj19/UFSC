#pragma once
#include <string>
#include "registers.h"

class CPU {
private:
    Registers defaultRegisters;

public:
    std::string name;
    Registers registers;
    void reset();
    CPU();
    CPU(std::string name_, Registers &registers_);
    ~CPU();
};