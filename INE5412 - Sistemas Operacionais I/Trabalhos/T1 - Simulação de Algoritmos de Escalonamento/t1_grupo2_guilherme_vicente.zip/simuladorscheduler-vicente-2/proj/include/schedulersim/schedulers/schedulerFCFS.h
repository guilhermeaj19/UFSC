#pragma once
#include "scheduler.h"

class SchedulerFCFS: public Scheduler {
    protected:
        int validator(TimeFrame *tf) override;
};