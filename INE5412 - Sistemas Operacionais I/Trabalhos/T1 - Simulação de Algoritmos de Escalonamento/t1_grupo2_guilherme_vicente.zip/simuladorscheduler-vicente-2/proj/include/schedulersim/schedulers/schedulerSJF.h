#pragma once
#include "scheduler.h"

class SchedulerSJF: public Scheduler {
    protected:
        int validator(TimeFrame *tf) override;
};