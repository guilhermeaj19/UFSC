#pragma once
#include <vector>
#include "quantum.h"

class TimeFrame {
private:
    std::vector<Quantum> quantumVec;
    std::vector<PCB> setup_vec;
public:
    TimeFrame();
    TimeFrame(std::vector<PCB> setup_vec_);
    ~TimeFrame();
    Quantum next(int pid);
    Quantum get(int n);
    Quantum back();
    float getAverageWait();
    int getContextChanges();
    int turnaround();
    void printResults();
    bool hasFinished();
};