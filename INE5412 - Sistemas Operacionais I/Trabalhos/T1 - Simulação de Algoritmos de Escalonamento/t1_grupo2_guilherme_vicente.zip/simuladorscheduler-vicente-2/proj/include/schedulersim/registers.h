#pragma once
#include <stdint.h>

struct Registers {
    int64_t gp[6];
    uint64_t sp;
    uint64_t pc;
    int64_t st;
};

Registers randomRegisters();