#pragma once
#include <optional>

#include "registers.h"
class PCB {
   private:
    // Adicionar função que cria o waiting time?
    int contextChanges{0};
    int waitingTime{0};
    int executionElapsed;
    int currentQuantum;

    void setRunningPCB(PCB* p);
    void setNonRunningPCB(PCB* p);

   public:
    enum states { NEW, READY, RUNNING, FINISHED };

    int pid;
    int start;
    int duration;
    int priority;

    int getContextChanges();
    int getWaitingTime();
    int getRemainingExecTime();
    int getCurrentQuantum();
    int getTurnAround();
    int getExecutionElapsed();
    bool hasFinished();
    bool canStart(int quantum);
    PCB step(bool running);

    Registers registers;
    states state;

    PCB();
    PCB(int pid_, int start_, int duration_, int priority_,
        int contextChanges_ = 0, int waitingTime_ = 0,
        int executionElapsed_ = 0, int currentQuantum_ = -1,
        Registers registers_ = randomRegisters(), states state_ = PCB::NEW);
};