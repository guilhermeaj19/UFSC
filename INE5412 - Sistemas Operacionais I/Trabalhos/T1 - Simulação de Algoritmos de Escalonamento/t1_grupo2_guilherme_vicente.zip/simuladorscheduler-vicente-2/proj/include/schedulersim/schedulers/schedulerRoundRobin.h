#pragma once
#include "scheduler.h"
#include <map>
#include <queue>

class SchedulerRoundRobin: public Scheduler {
    private:

        // std::map<int, int> lastExecutedPCB {{'p',-1}, {'t',0}};

    protected:
        int validator(TimeFrame *tf) override;
    public:
        std::queue<int> *pid_queue = new std::queue<int>();
        SchedulerRoundRobin(){};
        ~SchedulerRoundRobin();
};