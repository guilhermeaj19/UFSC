#pragma once
#include <vector>
#include <optional>
#include "pcb.h"
#include "cpu.h"

class Quantum {
private:
    std::optional<PCB> runningPCB;
    CPU cpu;
    std::vector<PCB> pcb_vec;
    int period;

    void resetContext();
    void setContext();

public:
    void push_back(PCB &pcb_);
    void insert(PCB &pcb_, int n);
    void erase(int n);
    void pop_back();
    std::size_t size();
    PCB get(int n);
    std::vector<PCB> get_vec();
    int getPeriod();
    float getAverageWait();
    int getContextChanges();
    float getAverageTurnAround();
    bool hasFinished();
    std::optional<PCB> getRunningPcb();
    Quantum step(int pid);

    Quantum();
    Quantum(int period_);
    Quantum(int period_, std::vector<PCB> &pcb_vec_);
    ~Quantum();
};