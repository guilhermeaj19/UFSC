#pragma once
#include "scheduler.h"

class SchedulerPriorityWithPreemption: public Scheduler {
    protected:
        int validator(TimeFrame *tf) override;
};