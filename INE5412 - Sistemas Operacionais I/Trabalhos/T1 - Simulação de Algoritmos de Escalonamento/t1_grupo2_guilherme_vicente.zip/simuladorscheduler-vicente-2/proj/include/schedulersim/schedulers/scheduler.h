#pragma once
#include <vector>
#include <string>
#include "../time_frame.h"

class Scheduler {
    protected:
        virtual int validator(TimeFrame *tf);
    public:
        TimeFrame execute(std::vector<PCB> &setup_vec);
};
