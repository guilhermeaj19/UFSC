#include <iostream>
#include "proj/include/input/read_file.h"
#include "proj/include/schedulersim/quantum.h"
#include "proj/include/schedulersim/time_frame.h"
#include "proj/include/schedulersim/utils.h"
// #include "proj/include/schedulersim/schedulers/schedulerPriorityNoPreemption.h"
// #include "proj/include/schedulersim/schedulers/schedulerPriorityWithPreemption.h"
#include "proj/include/schedulersim/schedulers/schedulerRoundRobin.h"
#include "proj/include/schedulersim/schedulers/schedulerFCFS.h"
// #include "proj/include/schedulersim/schedulers/schedulerSJF.h"
#include "proj/include/schedulersim/simulator.h"

int main(int argc, char* argv[]) {

  std::string filename = "entrada.txt";
  if (argc == 2) {
    filename = argv[1];
  }
    std::vector<PCB> setup_vec = createPCBVec(filename);
    if (setup_vec.size() == 0) {
      return -1;
    }

    Simulator s;
    s.execute(setup_vec);
    return 0;
}