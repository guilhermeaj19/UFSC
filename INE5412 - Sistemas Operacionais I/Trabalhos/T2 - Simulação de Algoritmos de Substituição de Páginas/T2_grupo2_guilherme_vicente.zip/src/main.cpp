#include "simulator.h"
#include <iostream>
#include <string>

int main(int argc, char* argv[]) {
    if (argc == 2) {
        int capacity = std::stoi(argv[1]);
        Simulator sim;
        sim.execute(capacity);
    } else {
        std::cout << "Comando incorreto! ./simulador [numero de quadros]" << std::endl;
    }
}