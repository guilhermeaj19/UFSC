#include "ram.h"

RAM::RAM() {}

RAM::RAM(int capacity_) { capacity = capacity_; }

void RAM::pop_front() { pageFrames.pop_front(); }

void RAM::pop_back() { pageFrames.pop_back(); }

void RAM::push_front(int page) {
    if (full()) {
        throw std::exception();
    } else {
        pageFrames.push_front(page);
    }
}

void RAM::push_back(int page) {
    if (full()) {
        throw std::exception();
    } else {
        pageFrames.push_back(page);
    }
}

void RAM::erase(std::deque<int>::iterator index) {
    pageFrames.erase(index);
}

void RAM::insert(std::deque<int>::iterator index, int page) {
    pageFrames.insert(index, page);
}

std::deque<int>::iterator RAM::find(int page) {
    return std::find(pageFrames.begin(), pageFrames.end(), page);
}

bool RAM::contains(int page) { return (find(page) != pageFrames.end()); }

bool RAM::full() { return (static_cast<int>(pageFrames.size()) >= capacity); }

int RAM::at(int index) {
    return pageFrames.at(index);
}

int RAM::size() {
    return pageFrames.size();
}
