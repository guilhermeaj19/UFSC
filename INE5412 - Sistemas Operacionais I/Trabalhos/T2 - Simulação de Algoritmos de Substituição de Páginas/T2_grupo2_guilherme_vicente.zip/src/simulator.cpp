#include "simulator.h"

void Simulator::execute(int capacity) {
    RAM ram{capacity};
    char page[50];
    int pageConverted;
    FIFO fifo{std::string("FIFO"), ram};
    LRU lru{std::string("LRU"), ram};
    OPT opt{std::string("OPT"), ram};

    while (!feof(stdin)) {
        char *teste = fgets(page, 50, stdin);
        if (teste != nullptr) {
            pageConverted = std::stoi(page);
            fifo.step(pageConverted);
            lru.step(pageConverted);
            opt.step(pageConverted);
            num_refs++;
        }
    }
    std::cout << capacity << " quadros" << std::endl;
    std::cout << num_refs << " refs" << std::endl;
    std::cout << fifo.get_name() << ": " << fifo.execute() << std::endl;
    std::cout << lru.get_name() << ": " << lru.execute() << std::endl;
    std::cout << opt.get_name() << ": " << opt.execute() << std::endl;
}
