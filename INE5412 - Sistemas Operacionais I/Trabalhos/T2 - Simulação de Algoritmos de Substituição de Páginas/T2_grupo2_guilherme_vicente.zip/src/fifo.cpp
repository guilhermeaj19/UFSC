#include "fifo.h"

FIFO::FIFO(std::string name_, RAM ram_) : Substituter(name_, ram_) {}

void FIFO::step(int page) {
    if (!ram.contains(page)) {
        if (ram.full()) {
            ram.pop_front();
        }
        ram.push_back(page);
        pf++;
    }
}
