#include "substituter.h"

Substituter::Substituter(std::string name_, RAM ram_) {
    name = name_;
    ram = ram_;
}

Substituter::Substituter() {}

std::string Substituter::get_name() { return name; }

void Substituter::step(int val) {}

int Substituter::execute() { return pf; }