#include "opt.h"

OPT::OPT(std::string name_, RAM ram_) : Substituter(name_, ram_) {}

void OPT::step(int page) {
    pageRefs.push(page);
    pageToRefTimes[page].push(time);
    time++;
}

int OPT::execute() {

    while (!pageRefs.empty()) {
        int s = pageRefs.front();

        if (!ram.contains(s)) {
            if (ram.full()) {
                determinePageToRemove();
            }
            ram.push_back(s);
            pf++;
        }

        pageToRefTimes[s].pop();
        pageRefs.pop();
    }
    return pf;
}

void OPT::determinePageToRemove() {
    int pageToRemove = (ram.at(0));

    for (int i = 1; i < ram.size(); i++) {
        if (pageToRefTimes[ram.at(i)].empty()) {
            pageToRemove = ram.at(i);
        } else {
            if ((pageToRefTimes[ram.at(i)].front() > pageToRefTimes[pageToRemove].front()) && !pageToRefTimes[pageToRemove].empty()) {
                pageToRemove = ram.at(i);
            }
        }
    }
    ram.erase(ram.find(pageToRemove));

}