#include "lru.h"

LRU::LRU(std::string name_, RAM ram_) : Substituter(name_, ram_) {}

void LRU::step(int page) {
    if (!ram.contains(page)) {
        if (ram.full()) {
            ram.pop_front();
        }
        ram.push_back(page);
        pf++;
    } else {
        std::deque<int>::iterator it = ram.find(page);
        ram.erase(it);
        ram.push_back(page);
    }
}
