#pragma once

#include <string>

#include "ram.h"

class Substituter {
   protected:
    RAM ram;
    int pf{0};
    std::string name;

   public:
    Substituter(std::string name_, RAM ram_);
    Substituter();
    std::string get_name();
    virtual void step(int val);
    virtual int execute();
};
