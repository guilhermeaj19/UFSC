#pragma once
#include <map>
#include <queue>
#include <string>
#include <vector>

#include "substituter.h"

class OPT : public Substituter {
   private:
    std::map<int, std::queue<int>> pageToRefTimes; // Dicionário com as páginas e seus momentos de execução em ordem
    int time{0}; // Momento de execução
    std::queue<int> pageRefs; //Fila com as referências de páginas

    void determinePageToRemove();

   public:
    OPT(std::string name_, RAM ram_);
    void step(int page) override;
    int execute() override;
};
