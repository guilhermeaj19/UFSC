#pragma once
#include <string>
#include "substituter.h"


class FIFO : public Substituter {
   public:
    FIFO(std::string name_, RAM ram_);
    void step(int page) override;
};
