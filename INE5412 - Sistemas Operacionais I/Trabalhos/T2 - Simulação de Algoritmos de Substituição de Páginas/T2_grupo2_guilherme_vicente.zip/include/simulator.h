#pragma once
#include "fifo.h"
#include "lru.h"
#include "opt.h"
#include <iostream>
#include <string>


class Simulator{
  private:
    int num_refs{0};
  public:
    void execute(int capacity);
};