#pragma once
#include <string>
#include "substituter.h"


class LRU : public Substituter {
   public:
    LRU(std::string name_, RAM ram_);
    void step(int page) override;
};
