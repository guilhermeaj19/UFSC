#pragma once

#include <deque>
#include <string>
#include <algorithm>

class RAM {
    private:
        int capacity;
        std::deque<int> pageFrames;

    public:
        RAM();
        RAM(int capacity_);
        void push_front(int page);
        void push_back(int page);
        void pop_front();
        void pop_back();
        void erase(std::deque<int>::iterator index);
        void insert(std::deque<int>::iterator index, int page);
        std::deque<int>::iterator find(int page);
        bool contains(int page);
        bool full();
        int at(int index);
        int size();
};
