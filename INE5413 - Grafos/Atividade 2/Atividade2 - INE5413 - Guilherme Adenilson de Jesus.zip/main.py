from menu import Menu

menu = Menu()
menu.mainMenu()